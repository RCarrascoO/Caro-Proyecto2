print('Este archivo ha sido movido a tools/sniff_mqtt.py')
print('Usa: python tools/sniff_mqtt.py desde la raíz del proyecto (después de activar .venv)')
