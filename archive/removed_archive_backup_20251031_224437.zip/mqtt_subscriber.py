print('Este archivo fue movido a src/clients/mqtt_subscriber.py')
print('Usa: python src\\clients\\mqtt_subscriber.py --config client1.json (después de activar .venv)')
