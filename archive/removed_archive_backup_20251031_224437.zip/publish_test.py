print('Este archivo fue movido a tools/publish_test.py')
print('Usa: python tools/publish_test.py desde la raíz del proyecto (después de activar .venv)')
