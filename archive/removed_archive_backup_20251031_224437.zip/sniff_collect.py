import json
import time
import threading
import argparse
print('Este archivo fue movido a tools/sniff_collect.py')
print('Usa: python tools/sniff_collect.py desde la raíz del proyecto (después de activar .venv)')
